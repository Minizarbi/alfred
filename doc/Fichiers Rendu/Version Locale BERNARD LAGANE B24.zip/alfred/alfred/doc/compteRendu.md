# Lundi

- Nous avons rencontré quelques difficultés sans vraiment savoir à chaque fois si les bugs venaient de nous ou non.
- Après avoir étudié en partie le code, nous avons créé 3 potions et 5 personnages avec chacun une stratégie et des caractéristiques spécifiques.
- Nous avons aussi ajouté un test pour le ramasseur.
- Nous avons ajouté une méthode pour fuir dans Deplacements.
- Nous avons ajouté une méthode pour trouver la potion la plus proche dans Calculs.

# Mardi

- Nous avons amélioré et débuggé la stratégie du ramasseur et du fuyard.
- Nous avons rajouté le personnage téléporteur.
- Nous avons modifié l'IHM pour afficher des images selon l'élément à afficher et utiliser un fond blanc.