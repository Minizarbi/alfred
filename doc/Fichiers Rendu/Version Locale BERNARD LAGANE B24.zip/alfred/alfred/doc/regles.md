# Caractéristiques
Une quantité de points donnée à répartir entre force et charisme, afin d'éviter les abus.

# Potions
## Potion d'invisibilité
Invisible pour un temps donné ou jusqu'au prochain mouvement.

## Potion de l'Oracle
Permet de voir les invisibles pour un temps donné.

## Potion de poison
Réduit les caractéristiques au lieu de les améliorer.

## Potion de charisme
Augmente seulement le charisme.

## Potion de force
Augmente seulement la force.

# Règles
## Limites de l'arène
Ajouter des murs à l'arène, une protection pour qu'on ne puisse pas sortir.
C'est l'arène qui vérifie que le personnage n'est pas à l'extérieur et prend les mesures nécessaires :
Impossibilité d'effectuer le déplacement demandé.
Téléportation automatique au point le plus proche du point demandé, mais à l'intérieur de l'arène.
Malus de force et/ou de charisme.
Mort punitive.

## Temps limite
Lorsqu'on dépasse le temps limite, il y a égalité.

# IHM
## Mode pas à pas
Un bouton qui permet de faire avancer progressivement le combat au lieu de le faire automatiquement toutes les secondes.
