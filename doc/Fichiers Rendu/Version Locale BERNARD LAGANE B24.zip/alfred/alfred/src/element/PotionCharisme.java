package element;

public class PotionCharisme extends Potion {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PotionCharisme() {
		super("potion_charisme", 0, 50);
	}

}
