package element;

public class PotionCharismeForce extends Potion {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PotionCharismeForce() {
		super("potion_charisme_force", 50, 50);
	}

}
