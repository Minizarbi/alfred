package element;

public class PotionForce extends Potion {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PotionForce() {
		super("potion_force", 50, 0);
	}

}
